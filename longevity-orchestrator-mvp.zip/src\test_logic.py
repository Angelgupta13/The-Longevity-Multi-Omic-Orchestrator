from agents.logic import LongevityPredictor

def test_logic():
    print("Verifying LongevityPredictor...")
    predictor = LongevityPredictor()
    
    # Test Case 1: Positive Outcome (Younger)
    bio_age = 65
    chrono_age = 72
    delta = predictor.calculate_aging_offset(chrono_age, bio_age)
    print(f"Test 1: Chrono {chrono_age}, Bio {bio_age} -> Delta {delta}")
    assert delta == -7.0
    
    # Test Case 2: Negative Outcome (Older)
    bio_age = 55
    chrono_age = 50
    delta = predictor.calculate_aging_offset(chrono_age, bio_age)
    print(f"Test 2: Chrono {chrono_age}, Bio {bio_age} -> Delta {delta}")
    assert delta == 5.0

    print("SUCCESS: Logic verification passed.")

if __name__ == "__main__":
    test_logic()
