# Longevity Multi-Omic Orchestrator (Imagine Cup 2026)

## Overview
This is the MVP for the **Longevity Multi-Omic Orchestrator**, a Multi-Agent System designed to predict biological aging offsets using genomic (TCGA) and clinical (MIMIC-IV) data.

## Features
- **Multi-Agent Architecture**: LeadOrchestrator, GenomicReasoner, ClinicalBioLinker, TrialMatcher.
- **Core Prediction Engine**: Calculates $\Delta = Age_{Biological} - Age_{Chronological}$.
- **Safety**: Built-in "Prompt Shield" and medical disclaimers.

## Project Structure
- `src/scenarios/longevity/config/agents.yaml`: Agent definitions.
- `src/agents/logic.py`: Prediction engine logic.
- `src/config/prompts.py`: Safety system messages.
- `src/verification_mock.html`: Browser simulation of the agent workflow.

## Running the MVP
1. **Install Dependencies**:
   ```bash
   pip install -r requirements.txt
   ```

2. **Run Logic Verification**:
   ```bash
   python src/test_logic.py
   ```

3. **View Agent Demo**:
   Open `src/verification_mock.html` in your browser to see the LeadOrchestrator in action.

## Azure Provisioning
To provision the full cloud backend (Azure AI Foundry, OneLake):
```bash
azd up
```
*(Note: Requires active Azure subscription and credentials).*
